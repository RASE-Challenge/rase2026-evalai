# evaluation_script/main.py
import json
from typing import Dict, Any

W = {"easy": 0.25, "medium": 0.35, "hard": 0.40}

def _weighted_metric(d: Dict[str, Dict[str, float]], key: str) -> float:
    return (
        float(d["easy"][key])   * W["easy"] +
        float(d["medium"][key]) * W["medium"] +
        float(d["hard"][key])   * W["hard"]
    )

def _compute_metrics(path: str) -> Dict[str, float]:
    # Accept nested-difficulty JSON OR flat JSON
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    if all(k in obj for k in ("easy", "medium", "hard")):
        pesq   = _weighted_metric(obj, "pesq")
        estoi  = _weighted_metric(obj, "estoi")
        dnsmos = _weighted_metric(obj, "dnsmos")
        mfcc   = _weighted_metric(obj, "mfcc_cs")
    else:
        pesq   = float(obj.get("pesq", 2.5))
        estoi  = float(obj.get("estoi", 0.70))
        dnsmos = float(obj.get("dnsmos", 3.0))
        mfcc   = float(obj.get("mfcc_cs", 0.85))
    total = (pesq + estoi + dnsmos + mfcc) / 4.0
    return {
        "PESQ": round(pesq, 4),
        "ESTOI": round(estoi, 4),
        "DNSMOS": round(dnsmos, 4),
        "MFCC-CS": round(mfcc, 4),
        "Total": round(total, 4),
    }

def evaluate(test_annotation_file: str,
             phase_codename: str,
             user_annotation_file: str = None,
             user_submission_file: str = None,
             **kwargs) -> Dict[str, Any]:
    # pick whichever filename is passed by the runner
    subfile = user_annotation_file or user_submission_file
    try:
        metrics = _compute_metrics(subfile) if subfile else {
            "PESQ": 2.5, "ESTOI": 0.7, "DNSMOS": 3.0, "MFCC-CS": 0.85, "Total": 0.76
        }
    except Exception:
        metrics = {"PESQ": 2.5, "ESTOI": 0.7, "DNSMOS": 3.0, "MFCC-CS": 0.85, "Total": 0.76}

    # --- NEW-STYLE (split codename -> metrics). Your split codename is "test".
    new_style = [{"test": metrics}]

    # --- OLD-STYLE (explicit fields). Some runners still expect this.
    old_style = [{
        "split": "test",
        "show_to_participant": True,
        "accuracies": metrics
    }]

    # Print for debugging (will appear in stdout link)
    print("Returning metrics:", json.dumps(metrics))

    return {
        # Provide BOTH styles to be safe
        "result": old_style,             # legacy format
        "evalai_result": new_style,      # newer format (some runners read this key)
        "submission_metadata": {
            "method_name": "Sanity Dummy",
            "score": metrics["Total"]
        },
        # helpful for UI
        "submission_result": {"test": metrics}
    }
